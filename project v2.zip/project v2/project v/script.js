// Toggle the chatbot open/close
function toggleChat() {
    const chatbot = document.getElementById("chatbotContainer");
    if (chatbot.style.display === "flex") {
      chatbot.style.display = "none";
    } else {
      chatbot.style.display = "flex";
      document.getElementById("chatInput").focus();
    }
  }
  
  // Handle sending a message
  document.getElementById("chatInput").addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      const userInput = this.value.trim();
      if (userInput === "") return;
  
      // Display user message
      addMessage("You", userInput);
  
      // Clear input field
      this.value = "";
  
      // Simulated AI response (replace this with real API call if needed)
      setTimeout(() => {
        const response = getAIResponse(userInput);
        addMessage("AI", response);
      }, 500);
    }
  });
  
  // Add message to chat body
  function addMessage(sender, text) {
    const chatBody = document.getElementById("chatBody");
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("chat-message");
    messageDiv.innerHTML = `<strong>${sender}:</strong> ${text}`;
    chatBody.appendChild(messageDiv);
  
    // Scroll to bottom
    chatBody.scrollTop = chatBody.scrollHeight;
  }
  
  // Dummy AI response logic
  function getAIResponse(input) {
    input = input.toLowerCase();
  
    if (input.includes("admission")) {
      return "You can check the admission process in the 'Admissions' section in the footer.";
    } else if (input.includes("vr tour")) {
      return "Click on the 'VR Tour' link in the navigation bar to begin exploring the NIET campus!";
    } else if (input.includes("contact")) {
      return "You can reach out via the contact page available on the NIET website.";
    } else if (input.includes("courses") || input.includes("programs")) {
      return "NIET offers UG, PG, and Diploma programs. Please visit the 'Academic' section below.";
    } else {
      return "I'm here to assist you with NIET. Try asking about admissions, courses, or the VR tour!";
    }
  }
  function speakDescription(area) {
  let description = '';

  switch (area) {
    case 'reception':
      description = 'Welcome to the Reception Area. Here, visitors are guided and assisted. You can get all initial queries resolved here.';
      break;
    case 'library':
      description = 'This is the NIET Library. A vast collection of academic books, journals, and digital resources is available for all students.';
      break;
    case 'lab':
      description = 'You are now entering the Computer Lab. It is equipped with high-end systems for practical learning and research.';
      break;
    default:
      description = 'Please select a valid area.';
  }

  const utterance = new SpeechSynthesisUtterance(description);
  utterance.rate = 1; // speaking speed
  utterance.pitch = 1; // voice tone
  speechSynthesis.speak(utterance);
}

  